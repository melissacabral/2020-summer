TODO
====

* add pagination to show 10 posts per page


* make a function to count the number of approved comments on any post
* make the comment form work with the real logged in user

* fix single so that an empty post_id doesn't break the query 


DONE
====
* make home page template
* improve the query on the home page
* make the dates look better
* set up the code debugger

* make single post template
* link all the images to the single template
* display all comments on single

* make the comment form
* parse the form - insert new comment into DB

* Add Searchbar form
* make search results template