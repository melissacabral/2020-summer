		<footer class="footer">
			&copy; 2020 Image App
		</footer>
		
	</div> <!-- end div.site -->

	<?php include('includes/debug-output.php'); ?>
</body>
</html>